<?php $__env->startSection('content'); ?>
	
	<div class="d-flex justify-content-between align-items-center my-4">
		<h4>Producten</h4>
		<div>
			<a href="<?php echo e(route('admin.products.create')); ?>">Nieuw product toevoegen</a>
		</div>
	</div>

	<table class="table table-striped table-hover">
		<tr>
			<th>Titel</th>
			<th>Prijs</th>
			<th colspan="4">&nbsp;</th>
		</tr>
		<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($product->title); ?></td>
				<td>&euro;<?php echo e($product->price); ?></td>
				<td>
					<?php if($product->active): ?>
						<span class="badge badge-success">Zichtbaar</span>
					<?php else: ?>
						<span class="badge badge-light">Onzichtbaar</span>
					<?php endif; ?>
				</td>
				<td>
					<?php if($product->leiding): ?>
						<span class="badge badge-info">Leiding</span>
					<?php else: ?>
						<span class="badge badge-primary">Leden</span>
					<?php endif; ?>
				</td>
				<td>
					<a href="<?php echo e(route('admin.products.edit', $product->id)); ?>">Aanpassen</a>
				</td>
				<td>
					<a href="<?php echo e(route('admin.products.types', $product->id)); ?>">Soorten en maten</a>
				</td>
			</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fabia\Documents\Laravel Projects\4Shop\resources\views/admin/products/index.blade.php ENDPATH**/ ?>