<?php $__env->startSection('content'); ?>

	<div class="d-flex justify-content-between align-items-center my-4">
		<h4>Catogorien</h4>
		<div>
			<a href="<?php echo e(route('admin.categories.create')); ?>">Nieuw product toevoegen</a>
		</div>
	</div>

    <table class="table table-striped table-hover">
        <tr>
            <th>Naam</th>
            <th>Actief</th>
            <th colspan="4">&nbsp;</th>
        </tr>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($category->name); ?></td>
                <td><?php echo e($category->active == 0 ? "Nee" : "Ja"); ?></td>
                <td>
                    <a href="<?php echo e(route('admin.categories.edit', $category->id)); ?>">Aanpassen</a>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fabia\Documents\Laravel Projects\4Shop\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>