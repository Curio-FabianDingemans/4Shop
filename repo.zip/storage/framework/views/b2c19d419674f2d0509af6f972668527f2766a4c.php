<?php $__env->startSection('content'); ?>

	<div class="products">
			<div class="product-row no-link" href="<?php echo e(route('products.show', $product)); ?>">
				<img src="<?php echo e(url($product->image ?? 'img/placeholder.jpg')); ?>" alt="<?php echo e($product->title); ?>" class="rounded">
				<div class="product-body">
					<form action="<?php echo e(route('products.order', $product)); ?>" method="POST" data-controller="size">
                        <div class="price-div">
                            <h5 class="product-title"><span><?php echo e($product->title); ?></span></h5>
                            <h5 class="product-title"><em>&euro;<?php echo e($product->getPriceAttribute($product->price)); ?></em></h5>
                        </div>
						<?php if (! (empty($product->description))): ?>
							<p><?php echo e($product->description); ?></p>
						<?php endif; ?>
                        <?php if($product->discount > 0): ?>
                            <span class="product-discount">Nu <strong><?php echo e($product->discount); ?>%</strong> kosting! Orginele prijs: €<?php echo e($product->price); ?></span>
                        <?php endif; ?>
						<?php if(count($product->types)): ?>
							<select name="type" id="type" class="form-control" data-action="change->size#update" data-target="size.type">
								<?php $__currentLoopData = $product->types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<option value="<?php echo e($type->id); ?>"><?php echo e($type->title); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</select>
							<div data-target="size.sizes">
								<?php $__currentLoopData = $product->types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<select class="form-control" data-type="<?php echo e($type->id); ?>" style="display: none;">
										<?php $__currentLoopData = $type->sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($size->id); ?>"><?php echo e($size->title); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
							<button type="submit" class="btn btn-success form-control">Bestellen &gt;</button>
							<?php echo e(csrf_field()); ?>

						<?php endif; ?>
					</form>
				</div>
			</div>
	</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fabia\Documents\Laravel Projects\4Shop\resources\views/products/show.blade.php ENDPATH**/ ?>