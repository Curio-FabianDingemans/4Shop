<h1>Bestelling #<?php echo e($order->slug); ?></h1>
<p><em><?php echo e($order->name); ?> (<?php echo e($order->speltak); ?>)</em></p>

<p>Uw bestelling is geplaatst! U ontvangt een mail zodra de bestelling opgehaald kan worden op het Scoutinggebouw.</p>

<?php if(!$order->payed): ?>
    <h3>Nog niet betaald</h3>
    <p>Let op: deze bestelling is nog niet betaald. U kunt de bestelling ook nog annuleren.</p>
    <p><a href="<?php echo e(route('order.show', [$order, $order->slug])); ?>">Ga naar de website om te betalen of te annuleren &gt;.</a></p>
<?php endif; ?>

<hr>
<table class="table mb-5">
    <?php $total = 0; ?>
    <?php $__currentLoopData = $order->rules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($rule->product); ?></td>
            <td><?php echo e($rule->type); ?> <?php echo e($rule->size); ?></td>
            <td class="text-right">&euro;<?php echo e($rule->price); ?></td>
            <?php $total += $rule->price; ?>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td colspan="2"><strong>Totaal</strong></td>
        <td class="text-right"><strong>&euro;<?php echo e(number_format($total, 2)); ?></strong></td>
    </tr>
</table><?php /**PATH C:\Users\fabia\Documents\Laravel Projects\4Shop\resources\views/emails/orderplaced.blade.php ENDPATH**/ ?>