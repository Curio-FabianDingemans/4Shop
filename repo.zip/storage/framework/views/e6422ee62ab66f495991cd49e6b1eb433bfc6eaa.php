<?php $__env->startSection('content'); ?>

	<h5><em>Bestellen</em></h5>
	<?php echo $__env->make('orders.partial_cart', ['remove' => false], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	
	<form action="<?php echo e(route('pay')); ?>" method="POST">
		<div class="form-group">
			<label for="name">Naam <?php echo e(session('type') == 'leden' ? 'jeugdlid' : ''); ?></label>
			<input type="text" class="form-control" id="name" name="name">
		</div>
		<div class="form-group">
			<label for="email">E-mailadres</label>
			<input type="email" class="form-control" id="email" name="email">
		</div>
		<div class="form-group">
			<label for="speltak"><?php echo e(session('type') == 'leden' ? 'Speltak' : 'Team'); ?></label>
			<select name="speltak" id="speltak" class="form-control">
				<option value="bevers">Bevers</option>
				<option value="hathi">Welpen Hathi</option>
				<option value="haveli">Welpen Haveli</option>
				<option value="scouts">Scouts</option>
				<option value="explorers">Explorers</option>
				<option value="overige">Overige</option>
			</select>
		</div>
		<div class="form-group d-flex justify-content-end">
			<button type="submit" class="btn btn-success">Bestellen &amp; betalen &gt;</button>
			<?php echo e(csrf_field()); ?>

		</div>
	</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\fabia\Documents\Laravel Projects\4Shop\resources\views/orders/order.blade.php ENDPATH**/ ?>